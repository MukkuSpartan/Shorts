"""Run this ONCE on your own computer to get the YouTube refresh token.

  1. pip install google-auth-oauthlib
  2. Put the client_secret.json you downloaded from Google Cloud next to this file
  3. python tools/get_youtube_token.py
  4. A browser opens → log in with the Google account that owns your YouTube channel
     → if you see "Google hasn't verified this app", click Advanced → Go to (app) → Allow
  5. Copy the three values it prints into your GitHub repo secrets.
"""
import json
import sys
from pathlib import Path

from google_auth_oauthlib.flow import InstalledAppFlow

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

here = Path(__file__).resolve().parent
candidates = [here / "client_secret.json", Path.cwd() / "client_secret.json"]
candidates += sorted(Path.cwd().glob("client_secret*.json")) + sorted(here.glob("client_secret*.json"))
secret_file = next((p for p in candidates if p.exists()), None)
if not secret_file:
    sys.exit("client_secret.json not found. Download it from Google Cloud → Credentials → your OAuth client.")

flow = InstalledAppFlow.from_client_secrets_file(str(secret_file), SCOPES)
creds = flow.run_local_server(port=0, access_type="offline", prompt="consent")
info = json.loads(secret_file.read_text())
client = info.get("installed") or info.get("web") or {}

print("\nAdd these as GitHub repository secrets:\n")
print(f"YT_CLIENT_ID      = {client.get('client_id')}")
print(f"YT_CLIENT_SECRET  = {client.get('client_secret')}")
print(f"YT_REFRESH_TOKEN  = {creds.refresh_token}")
print("\nKeep these private — anyone with them can upload to your channel.")
