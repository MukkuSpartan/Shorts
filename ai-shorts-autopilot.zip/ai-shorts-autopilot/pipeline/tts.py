"""AI narration with word-level timestamps (for synced captions).

Primary: edge-tts — Microsoft's free neural voices (very natural, 400+ voices).
Fallback: gTTS (Google Translate voice) with estimated word timings.
"""
from __future__ import annotations

import asyncio
import random
import re
from pathlib import Path

from .utils import ffprobe_duration, log

Word = dict  # {"text": str, "start": float, "end": float}


async def _edge(text: str, voice: str, rate: str, pitch: str, out: Path) -> list[Word]:
    import edge_tts

    try:
        comm = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch, boundary="WordBoundary")
    except TypeError:  # edge-tts < 7 (word boundaries were the default)
        comm = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)

    words: list[Word] = []
    with open(out, "wb") as f:
        async for chunk in comm.stream():
            if chunk["type"] == "audio":
                f.write(chunk["data"])
            elif chunk["type"] == "WordBoundary":
                start = chunk["offset"] / 1e7
                words.append({"text": chunk["text"], "start": start,
                              "end": start + chunk["duration"] / 1e7})
    return words


def estimate_words(text: str, duration: float) -> list[Word]:
    """Spread words across the audio in proportion to their length."""
    tokens = text.split()
    weights = [len(t) + 2 + (6 if re.search(r"[.!?]$", t) else 3 if t.endswith(",") else 0)
               for t in tokens]
    total = sum(weights) or 1
    t, words = 0.15, []
    usable = max(duration - 0.3, 0.5)
    for tok, w in zip(tokens, weights):
        d = usable * w / total
        words.append({"text": re.sub(r"[^\w'’-]", "", tok) or tok, "start": t, "end": t + d * 0.85})
        t += d
    return words


def _gtts(text: str, lang: str, out: Path) -> list[Word]:
    from gtts import gTTS
    gTTS(text=text, lang=lang).save(str(out))
    return estimate_words(text, ffprobe_duration(out))


def _speed_up(rate: str, factor: float) -> str:
    cur = int(re.sub(r"[^\d-]", "", rate) or 0)
    new = min(cur + int(round((factor - 1) * 100)) + 2, 35)
    return f"{'+' if new >= 0 else ''}{new}%"


def synthesize(text: str, cfg: dict, out: Path) -> tuple[list[Word], float, str]:
    """Returns (words, duration_seconds, voice_used). Keeps length under max_seconds."""
    vcfg, vid = cfg["voice"], cfg["video"]
    voices = list(vcfg.get("voices") or ["en-US-AndrewMultilingualNeural"])
    voice = random.choice(voices) if vcfg.get("rotate", True) else voices[0]
    rate, pitch = vcfg.get("rate", "+0%"), vcfg.get("pitch", "+0Hz")
    max_s = float(vid["max_seconds"])

    for attempt in range(3):
        try:
            log(f"TTS edge-tts voice={voice} rate={rate}")
            words = asyncio.run(_edge(text, voice, rate, pitch, out))
            dur = ffprobe_duration(out)
            if dur <= 0:
                raise RuntimeError("empty audio")
            if not words:
                words = estimate_words(text, dur)
            if dur > max_s and attempt < 2:
                rate = _speed_up(rate, dur / max_s)
                log(f"  {dur:.1f}s is too long → re-voicing at {rate}")
                continue
            return words, dur, voice
        except Exception as e:  # network hiccup, voice removed, etc.
            log(f"  edge-tts failed: {e}")
            if attempt == 1 and len(voices) > 1:
                voice = random.choice([v for v in voices if v != voice])

    lang = (voice.split("-")[0] if voice else "en") or "en"
    log("TTS fallback → gTTS")
    words = _gtts(text, lang, out)
    return words, ffprobe_duration(out), f"gtts-{lang}"
