"""Uploads the short to YouTube with the official Data API v3 (free quota).

Needs secrets: YT_CLIENT_ID, YT_CLIENT_SECRET, YT_REFRESH_TOKEN
(get the refresh token once with tools/get_youtube_token.py).
"""
from __future__ import annotations

import time
from pathlib import Path

from .utils import env, log


def _service():
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build

    creds = Credentials(
        token=None,
        refresh_token=env("YT_REFRESH_TOKEN"),
        client_id=env("YT_CLIENT_ID"),
        client_secret=env("YT_CLIENT_SECRET"),
        token_uri="https://oauth2.googleapis.com/token",
        scopes=["https://www.googleapis.com/auth/youtube.upload"],
    )
    return build("youtube", "v3", credentials=creds, cache_discovery=False)


def configured() -> bool:
    return all(env(k) for k in ("YT_CLIENT_ID", "YT_CLIENT_SECRET", "YT_REFRESH_TOKEN"))


def upload(video: Path, script: dict, cfg: dict) -> dict:
    from googleapiclient.errors import HttpError
    from googleapiclient.http import MediaFileUpload

    yc = cfg["youtube"]
    title = script["title"].strip()
    if yc.get("add_shorts_tag", True) and "#shorts" not in title.lower():
        title = f"{title[:90]} #Shorts"
    tags = " ".join(f"#{h}" for h in script.get("hashtags", [])[:5])
    description = f"{script.get('description', '').strip()}\n\n{tags}\n\nNarration and visuals are AI-assisted."
    body = {
        "snippet": {
            "title": title[:100],
            "description": description[:4900],
            "tags": script.get("tags", [])[:15],
            "categoryId": str(yc.get("category_id", "27")),
        },
        "status": {
            "privacyStatus": yc.get("privacy", "public"),
            "selfDeclaredMadeForKids": bool(yc.get("made_for_kids", False)),
            "containsSyntheticMedia": True,
        },
    }

    yt = _service()
    for attempt in range(3):
        try:
            media = MediaFileUpload(str(video), mimetype="video/mp4", chunksize=8 * 1024 * 1024, resumable=True)
            req = yt.videos().insert(part="snippet,status", body=body, media_body=media)
            resp = None
            while resp is None:
                _, resp = req.next_chunk()
            vid = resp["id"]
            status = resp.get("status", {}).get("privacyStatus")
            log(f"YouTube ✓ https://youtube.com/shorts/{vid} (privacy: {status})")
            return {"id": vid, "url": f"https://youtube.com/shorts/{vid}", "privacy": status}
        except HttpError as e:
            msg = str(e)
            if "containsSyntheticMedia" in msg:
                body["status"].pop("containsSyntheticMedia", None)
                continue
            if e.resp.status in (500, 502, 503, 504) and attempt < 2:
                time.sleep(10 * (attempt + 1))
                continue
            raise RuntimeError(f"YouTube upload failed: {msg[:500]}")
    raise RuntimeError("YouTube upload failed after retries")
