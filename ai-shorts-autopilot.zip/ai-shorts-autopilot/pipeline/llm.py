"""Free LLM access: Google Gemini (AI Studio free tier) with Groq as backup.

Both return strict JSON. Model names change over time, so each provider has a
list of models tried in order (edit them in config.yaml).
"""
from __future__ import annotations

import json
import re
import time

import requests

from .utils import env, log


class LLMError(RuntimeError):
    pass


def _extract_json(text: str) -> dict:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, re.S)
        if m:
            return json.loads(m.group(0))
        raise


def _gemini(system: str, prompt: str, model: str, temperature: float) -> dict:
    key = env("GEMINI_API_KEY")
    if not key:
        raise LLMError("GEMINI_API_KEY not set")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    body = {
        "systemInstruction": {"parts": [{"text": system}]},
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": temperature,
            "responseMimeType": "application/json",
        },
    }
    r = requests.post(url, json=body, headers={"x-goog-api-key": key}, timeout=120)
    if r.status_code != 200:
        raise LLMError(f"Gemini {model}: HTTP {r.status_code} {r.text[:300]}")
    data = r.json()
    try:
        text = "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"])
    except (KeyError, IndexError):
        raise LLMError(f"Gemini {model}: unexpected response {str(data)[:300]}")
    return _extract_json(text)


def _groq(system: str, prompt: str, model: str, temperature: float) -> dict:
    key = env("GROQ_API_KEY")
    if not key:
        raise LLMError("GROQ_API_KEY not set")
    r = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers={"Authorization": f"Bearer {key}"},
        json={
            "model": model,
            "temperature": temperature,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
        },
        timeout=120,
    )
    if r.status_code != 200:
        raise LLMError(f"Groq {model}: HTTP {r.status_code} {r.text[:300]}")
    return _extract_json(r.json()["choices"][0]["message"]["content"])


def generate_json(system: str, prompt: str, cfg: dict) -> dict:
    llm = cfg.get("llm", {})
    temperature = float(llm.get("temperature", 0.9))
    attempts: list[tuple[str, str]] = []
    for provider in llm.get("providers", ["gemini", "groq"]):
        for model in llm.get(f"{provider}_models", []):
            attempts.append((provider, model))

    errors: list[str] = []
    no_key: set[str] = set()
    for provider, model in attempts:
        if provider in no_key:
            continue
        fn = _gemini if provider == "gemini" else _groq
        for retry in range(2):
            try:
                log(f"LLM → {provider}/{model}")
                return fn(system, prompt, model, temperature)
            except LLMError as e:
                errors.append(str(e))
                log(f"  failed: {str(e)[:160]}")
                if "not set" in str(e):
                    no_key.add(provider)
                    break
                if "429" in str(e) and retry == 0:   # rate limited: wait once
                    time.sleep(20)
                    continue
                break
            except (json.JSONDecodeError, requests.RequestException, KeyError) as e:
                errors.append(f"{provider}/{model}: {e}")
                log(f"  failed: {e}")
                break
    raise LLMError("All LLM providers failed:\n" + "\n".join(errors[-6:]))
