"""Assembles the final 9:16 video with ffmpeg: scene clips → captions → voice + music."""
from __future__ import annotations

import random
from pathlib import Path

from .utils import ASSETS, WORK, ffprobe_duration, log, normalize_word, run

GRADIENTS = [("0x1e3c72", "0x2a5298"), ("0x42275a", "0x734b6d"), ("0x0f2027", "0x2c5364"),
             ("0x3a1c71", "0xd76d77"), ("0x134e5e", "0x71b280"), ("0x232526", "0x414345")]


# ── timing ──────────────────────────────────────────────────────────────────
def scene_timings(scenes: list[dict], words: list[dict], total: float) -> list[tuple[float, float]]:
    """Map each scene's text onto the spoken word timeline (by character position)."""
    scene_chars = [sum(len(normalize_word(w)) for w in s["text"].split()) for s in scenes]
    word_chars = [len(normalize_word(w["text"])) for w in words]
    total_sc, total_wc = sum(scene_chars) or 1, sum(word_chars) or 1

    # cumulative fraction of characters at the end of each scene
    bounds, acc = [], 0
    for c in scene_chars[:-1]:
        acc += c
        bounds.append(acc / total_sc)

    starts = [0.0]
    cum, wi = 0, 0
    for frac in bounds:
        target = frac * total_wc
        while wi < len(words) and cum + word_chars[wi] / 2 < target:
            cum += word_chars[wi]
            wi += 1
        starts.append(words[wi]["start"] if wi < len(words) else total * frac)
    ends = starts[1:] + [total]
    out = []
    for a, b in zip(starts, ends):
        out.append((a, max(b, a + 0.8)))
    return out


# ── per-scene clips ─────────────────────────────────────────────────────────
def _vf_base(w: int, h: int, fps: int) -> str:
    return (f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},"
            f"setsar=1,fps={fps},format=yuv420p")


def make_clip(media: dict, dur: float, idx: int, cfg: dict) -> Path:
    v = cfg["video"]
    w, h, fps = v["width"], v["height"], v["fps"]
    out = WORK / f"clip_{idx:02d}.mp4"
    enc = ["-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
           "-pix_fmt", "yuv420p", "-r", str(fps), "-t", f"{dur:.3f}"]
    kind, path = media["kind"], media.get("path")

    if kind == "video" and path:
        src_dur = ffprobe_duration(path)
        start = random.uniform(0, max(src_dur - dur - 0.5, 0)) if src_dur > dur + 1 else 0
        run(["ffmpeg", "-y", "-ss", f"{start:.2f}", "-stream_loop", "-1", "-i", str(path),
             "-vf", _vf_base(w, h, fps) + ",eq=saturation=1.08", *enc, str(out)])
        return out

    if kind == "image" and path:
        frames = int(dur * fps) + 2
        zoom_in = idx % 2 == 0
        z = "min(1.0+0.0009*on,1.25)" if zoom_in else "max(1.25-0.0009*on,1.0)"
        x = "iw/2-(iw/zoom/2)" if idx % 3 else "(iw-iw/zoom)*on/%d" % frames
        big_w, big_h = w * 3 // 2, h * 3 // 2
        vf = (f"scale={big_w}:{big_h}:force_original_aspect_ratio=increase,crop={big_w}:{big_h},"
              f"zoompan=z='{z}':x='{x}':y='ih/2-(ih/zoom/2)':d={frames}:s={w}x{h}:fps={fps},"
              f"setsar=1,format=yuv420p")
        run(["ffmpeg", "-y", "-loop", "1", "-i", str(path), "-vf", vf, *enc, str(out)])
        return out

    c0, c1 = GRADIENTS[idx % len(GRADIENTS)]
    try:
        run(["ffmpeg", "-y", "-f", "lavfi", "-i",
             f"gradients=s={w}x{h}:c0={c0}:c1={c1}:speed=0.015:r={fps}:d={dur:.3f}",
             "-vf", "format=yuv420p", *enc, str(out)])
    except RuntimeError:
        run(["ffmpeg", "-y", "-f", "lavfi", "-i", f"color=c={c0}:s={w}x{h}:r={fps}:d={dur:.3f}",
             *enc, str(out)])
    return out


# ── captions (ASS, word-by-word highlight) ─────────────────────────────────
def _ass_color(hex_rgb: str) -> str:
    h = hex_rgb.lstrip("#")
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H00{b}{g}{r}".upper()


def _ts(t: float) -> str:
    t = max(t, 0)
    hh, rem = divmod(t, 3600)
    mm, ss = divmod(rem, 60)
    return f"{int(hh)}:{int(mm):02d}:{ss:05.2f}"


def _esc(s: str) -> str:
    return s.replace("\\", "").replace("{", "(").replace("}", ")")


def build_captions(words: list[dict], total: float, cfg: dict, path: Path) -> Path:
    v, c = cfg["video"], cfg["video"]["captions"]
    w, h = v["width"], v["height"]
    hl = _ass_color(c.get("highlight_color", "#FFE135"))
    per_line = int(c.get("words_per_line", 3))
    upper = c.get("uppercase", True)

    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {w}
PlayResY: {h}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{c.get('font', 'Poppins')},{c.get('size', 88)},&H00FFFFFF,&H00FFFFFF,&H00000000,&H96000000,-1,0,0,0,100,100,1,0,1,7,3,2,70,70,{c.get('position_from_bottom', 560)},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    words = [dict(x) for x in words if normalize_word(x["text"])]
    lines = []
    # break chunks at sentence ends as well as every N words
    chunks, cur = [], []
    for wd in words:
        cur.append(wd)
        if len(cur) >= per_line or wd["text"].rstrip().endswith((".", "!", "?")):
            chunks.append(cur)
            cur = []
    if cur:
        chunks.append(cur)

    for ci, chunk in enumerate(chunks):
        chunk_end = chunks[ci + 1][0]["start"] if ci + 1 < len(chunks) else total
        chunk_end = min(chunk_end, chunk[-1]["end"] + 0.6)
        texts = [_esc(x["text"].upper() if upper else x["text"]) for x in chunk]
        for wi, wd in enumerate(chunk):
            start = wd["start"]
            end = chunk[wi + 1]["start"] if wi + 1 < len(chunk) else chunk_end
            if end - start < 0.03:
                continue
            parts = []
            for k, t in enumerate(texts):
                if k == wi:
                    parts.append(r"{\c" + hl + r"&\fscx112\fscy112}" + t + r"{\r}")
                else:
                    parts.append(t)
            pop = r"{\fscx90\fscy90\t(0,90,\fscx100\fscy100)}" if wi == 0 else ""
            lines.append(f"Dialogue: 0,{_ts(start)},{_ts(end)},Cap,,0,0,0,,{pop}{' '.join(parts)}")

    path.write_text(header + "\n".join(lines) + "\n", encoding="utf-8")
    return path


# ── final assembly ──────────────────────────────────────────────────────────
def _ff_path(p: Path) -> str:
    """Escape a path for use inside an ffmpeg filter argument."""
    return str(p).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")


def render_video(script: dict, words: list[dict], audio: Path, audio_dur: float,
                 cfg: dict, out_path: Path) -> Path:
    v = cfg["video"]
    WORK.mkdir(parents=True, exist_ok=True)
    total = audio_dur + 0.6  # small tail after the last word
    timings = scene_timings(script["scenes"], words, total)

    clips = []
    for i, (scene, (a, b)) in enumerate(zip(script["scenes"], timings)):
        clips.append(make_clip(scene["media"], b - a, i, cfg))
    log(f"Built {len(clips)} scene clips")

    concat_list = WORK / "concat.txt"
    concat_list.write_text("".join(f"file '{c.resolve()}'\n" for c in clips))
    joined = WORK / "joined.mp4"
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_list), "-c", "copy", str(joined)])

    filters = ["[0:v]eq=brightness=-0.04:contrast=1.05[v0]"]
    last = "v0"
    if v.get("progress_bar", True):
        filters.append(f"color=c=white@0.9:s={v['width']}x12:r={v['fps']},format=rgba[bar]")
        filters.append(f"[{last}][bar]overlay=x='-w+w*t/{total:.3f}':y=0:eval=frame:shortest=1[v1]")
        last = "v1"
    if v["captions"].get("enabled", True):
        ass = build_captions(words, total, cfg, WORK / "captions.ass")
        filters.append(f"[{last}]ass='{_ff_path(ass)}':fontsdir='{_ff_path(ASSETS / 'fonts')}'[v2]")
        last = "v2"

    inputs = ["-i", str(joined), "-i", str(audio)]
    music = sorted((ASSETS / "music").glob("*.mp3")) + sorted((ASSETS / "music").glob("*.m4a"))
    if music:
        track = random.choice(music)
        log(f"Music: {track.name}")
        inputs += ["-stream_loop", "-1", "-i", str(track)]
        vol = float(v.get("music_volume", 0.1))
        filters.append(f"[1:a]aresample=48000,apad[voice]")
        filters.append(f"[2:a]aresample=48000,volume={vol},afade=t=out:st={total - 1.5:.2f}:d=1.5[bg]")
        filters.append("[voice][bg]amix=inputs=2:duration=first:normalize=0,"
                       "loudnorm=I=-14:TP=-1.5:LRA=11[a]")
    else:
        filters.append("[1:a]aresample=48000,apad,loudnorm=I=-14:TP=-1.5:LRA=11[a]")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    run(["ffmpeg", "-y", *inputs, "-filter_complex", ";".join(filters),
         "-map", f"[{last}]", "-map", "[a]", "-t", f"{total:.3f}",
         "-c:v", "libx264", "-preset", "medium", "-crf", "21", "-profile:v", "high",
         "-pix_fmt", "yuv420p", "-r", str(v["fps"]), "-maxrate", "8M", "-bufsize", "16M",
         "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
         "-movflags", "+faststart", str(out_path)])
    log(f"Rendered {out_path.name} ({ffprobe_duration(out_path):.1f}s)")
    return out_path
