"""Publishes the short as an Instagram Reel through Meta's official API (free).

Two modes (config.yaml → instagram.api):
  "instagram": Instagram API with Instagram Login. Secrets: IG_ACCESS_TOKEN (+ optional IG_USER_ID).
               Instagram downloads the video from a public URL — we serve it from GitHub Pages.
  "facebook":  Instagram API with Facebook Login. Secrets: IG_ACCESS_TOKEN, IG_USER_ID.
               The file is uploaded directly (resumable upload), no public URL needed.
"""
from __future__ import annotations

import time
from pathlib import Path

import requests

from .utils import env, log


def configured() -> bool:
    return bool(env("IG_ACCESS_TOKEN"))


def _caption(script: dict) -> str:
    tags = " ".join(f"#{h}" for h in script.get("hashtags", [])[:8])
    cap = script.get("caption") or script["title"]
    return f"{cap}\n\n{tags}".strip()[:2150]


def _check(r: requests.Response, what: str) -> dict:
    try:
        data = r.json()
    except ValueError:
        data = {}
    if r.status_code != 200 or "error" in data:
        raise RuntimeError(f"Instagram {what} failed: HTTP {r.status_code} {str(data or r.text)[:500]}")
    return data


def publish(video: Path, script: dict, cfg: dict, video_url: str = "") -> dict:
    ic = cfg["instagram"]
    mode = ic.get("api", "instagram")
    ver = ic.get("graph_version", "v25.0")
    host = "https://graph.instagram.com" if mode == "instagram" else "https://graph.facebook.com"
    base = f"{host}/{ver}"
    token = env("IG_ACCESS_TOKEN")
    user_id = env("IG_USER_ID")

    if not user_id:
        me = _check(requests.get(f"{base}/me", params={"fields": "user_id,username,id",
                                                        "access_token": token}, timeout=30), "lookup")
        user_id = str(me.get("user_id") or me.get("id"))
        log(f"Instagram account: @{me.get('username')} ({user_id})")

    params = {"media_type": "REELS", "caption": _caption(script),
              "share_to_feed": str(ic.get("share_to_feed", True)).lower(), "access_token": token}

    if mode == "facebook":
        params["upload_type"] = "resumable"
        data = _check(requests.post(f"{base}/{user_id}/media", data=params, timeout=60), "container")
        cid = data["id"]
        size = video.stat().st_size
        with open(video, "rb") as f:
            r = requests.post(f"https://rupload.facebook.com/ig-api-upload/{ver}/{cid}",
                              headers={"Authorization": f"OAuth {token}", "offset": "0",
                                       "file_size": str(size)}, data=f, timeout=600)
        _check(r, "file upload")
    else:
        if not video_url:
            raise RuntimeError("Instagram Login mode needs a public video URL (GitHub Pages)")
        params["video_url"] = video_url
        data = _check(requests.post(f"{base}/{user_id}/media", data=params, timeout=60), "container")
        cid = data["id"]

    # Wait for Instagram to process the video
    log(f"Instagram container {cid} created, waiting for processing…")
    for _ in range(60):  # up to ~10 minutes
        time.sleep(10)
        st = _check(requests.get(f"{base}/{cid}", params={"fields": "status_code,status",
                                                          "access_token": token}, timeout=30), "status")
        code = st.get("status_code")
        if code == "FINISHED":
            break
        if code in ("ERROR", "EXPIRED"):
            raise RuntimeError(f"Instagram processing failed: {st}")
    else:
        raise RuntimeError("Instagram processing timed out")

    pub = _check(requests.post(f"{base}/{user_id}/media_publish",
                               data={"creation_id": cid, "access_token": token}, timeout=60), "publish")
    media_id = pub["id"]
    link = ""
    try:
        link = _check(requests.get(f"{base}/{media_id}", params={"fields": "permalink",
                                                                 "access_token": token}, timeout=30),
                      "permalink").get("permalink", "")
    except RuntimeError:
        pass
    log(f"Instagram ✓ {link or media_id}")
    return {"id": media_id, "url": link}
