"""Command-line entry point.

  python -m pipeline.main make [--topic "..."] [--youtube]   # build video (+ upload to YouTube)
  python -m pipeline.main instagram --video-url URL          # publish the built video as a Reel
  python -m pipeline.main finalize                           # record history, pop topic from queue

On your own computer, `python -m pipeline.main make --topic "Why is the sky blue"`
just builds out/video.mp4 so you can preview it.
"""
from __future__ import annotations

import argparse
import datetime as dt
import shutil
import sys
import traceback

from . import media, render, script_gen, tts, upload_instagram, upload_youtube
from .utils import DATA, OUT, WORK, load_config, log, read_json, slugify, write_json

POST = OUT / "post.json"


def pick_topic(cfg: dict, override: str = "") -> tuple[str, str]:
    if override.strip():
        return override.strip(), "manual"
    queue = read_json(DATA / "topics.json", {"queue": []}).get("queue", [])
    if queue:
        return queue[0], "queue"
    history = read_json(DATA / "history.json", [])
    return script_gen.invent_topic(cfg, [h.get("title", "") for h in history]), "ai"


def cmd_make(args) -> int:
    cfg = load_config()
    shutil.rmtree(WORK, ignore_errors=True)
    WORK.mkdir(parents=True, exist_ok=True)

    topic, source = pick_topic(cfg, args.topic or "")
    log(f"Topic ({source}): {topic}")
    script = script_gen.write_script(topic, cfg)

    narration = " ".join(s["text"] for s in script["scenes"])
    audio = WORK / "voice.mp3"
    words, dur, voice = tts.synthesize(narration, cfg, audio)
    log(f"Narration: {dur:.1f}s, {len(words)} words, voice {voice}")

    media.fetch_visuals(script["scenes"], cfg)
    video = OUT / "video.mp4"
    render.render_video(script, words, audio, dur, cfg, video)

    now = dt.datetime.now(dt.timezone.utc)
    post = {
        "id": now.strftime("%Y%m%d-%H%M") + "-" + slugify(script["title"], 40),
        "created": now.isoformat(timespec="seconds"),
        "topic": topic,
        "topic_source": source,
        "title": script["title"],
        "description": script.get("description", ""),
        "caption": script.get("caption", ""),
        "hashtags": script.get("hashtags", []),
        "tags": script.get("tags", []),
        "narration": narration,
        "voice": voice,
        "duration": round(dur, 1),
        "visuals": [s["media"]["kind"] for s in script["scenes"]],
        "youtube": None,
        "instagram": None,
        "errors": [],
    }

    if args.youtube:
        if not cfg["youtube"].get("enabled", True):
            log("YouTube disabled in config")
        elif not upload_youtube.configured():
            log("YouTube secrets not set — skipping upload")
        else:
            try:
                post["youtube"] = upload_youtube.upload(video, script, cfg)
            except Exception as e:
                post["errors"].append(f"youtube: {e}")
                log(f"YouTube ERROR: {e}")

    write_json(POST, post)
    log(f"Done: {video}")
    return 0


def cmd_instagram(args) -> int:
    cfg = load_config()
    post = read_json(POST, None)
    if not post:
        log("No out/post.json — run `make` first")
        return 1
    if not cfg["instagram"].get("enabled", True):
        log("Instagram disabled in config")
        return 0
    if not upload_instagram.configured():
        log("Instagram secrets not set — skipping")
        return 0
    script = {"title": post["title"], "caption": post["caption"], "hashtags": post["hashtags"]}
    try:
        post["instagram"] = upload_instagram.publish(OUT / "video.mp4", script, cfg, args.video_url or "")
    except Exception as e:
        post["errors"].append(f"instagram: {e}")
        log(f"Instagram ERROR: {e}")
    write_json(POST, post)
    return 0


def cmd_finalize(args) -> int:
    post = read_json(POST, None)
    if not post:
        log("Nothing to finalize")
        return 0
    if args.video_url:
        post["video_url"] = args.video_url
    history = read_json(DATA / "history.json", [])
    history.insert(0, {k: post.get(k) for k in (
        "id", "created", "topic", "topic_source", "title", "voice", "duration",
        "youtube", "instagram", "errors", "video_url")})
    write_json(DATA / "history.json", history[:500])

    topics = read_json(DATA / "topics.json", {"queue": []})
    if post.get("topic_source") == "queue" and post["topic"] in topics.get("queue", []):
        topics["queue"].remove(post["topic"])
        write_json(DATA / "topics.json", topics)
    log("History updated")
    # Fail the workflow run (so you get GitHub's email) if every enabled upload failed
    uploaded = post.get("youtube") or post.get("instagram")
    return 1 if post.get("errors") and not uploaded else 0


def main() -> int:
    p = argparse.ArgumentParser(prog="pipeline")
    sub = p.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("make")
    m.add_argument("--topic", default="")
    m.add_argument("--youtube", action="store_true", help="also upload to YouTube")
    i = sub.add_parser("instagram")
    i.add_argument("--video-url", default="")
    f = sub.add_parser("finalize")
    f.add_argument("--video-url", default="")
    args = p.parse_args()
    try:
        return {"make": cmd_make, "instagram": cmd_instagram, "finalize": cmd_finalize}[args.cmd](args)
    except Exception:
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
