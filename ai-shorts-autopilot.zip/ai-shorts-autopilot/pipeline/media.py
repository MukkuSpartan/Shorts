"""Finds a visual for every scene.

Order of preference depends on video.visual_mode:
  stock: Pexels video → Pixabay video → AI image → gradient
  ai:    AI image → Pexels video → Pixabay video → gradient
Every source is free (Pexels/Pixabay need a free API key; Pollinations works without one).
"""
from __future__ import annotations

import hashlib
import random
import urllib.parse
from pathlib import Path

import requests

from .utils import CACHE, env, log

UA = {"User-Agent": "ai-shorts-autopilot/1.0"}


def _download(url: str, dest: Path, headers: dict | None = None, timeout: int = 120) -> Path | None:
    if dest.exists() and dest.stat().st_size > 10_000:
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        with requests.get(url, headers={**UA, **(headers or {})}, stream=True, timeout=timeout) as r:
            if r.status_code != 200:
                return None
            ctype = r.headers.get("content-type", "")
            if "json" in ctype or "html" in ctype:
                return None
            with open(dest, "wb") as f:
                for chunk in r.iter_content(1 << 16):
                    f.write(chunk)
        return dest if dest.stat().st_size > 10_000 else None
    except requests.RequestException:
        return None


def _pick_file(files: list[dict]) -> dict | None:
    """Prefer portrait files ~1080x1920, then the largest reasonable landscape one."""
    def score(f):
        w, h = f.get("width") or 0, f.get("height") or 0
        portrait = h > w
        return (portrait, min(h, 1920) if portrait else min(w, 1920), -(w * h))
    files = [f for f in files if (f.get("width") or 0) * (f.get("height") or 0) <= 2160 * 3840]
    return max(files, key=score) if files else None


def pexels_video(query: str, used: set) -> Path | None:
    key = env("PEXELS_API_KEY")
    if not key:
        return None
    for orientation in ("portrait", None):
        params = {"query": query, "per_page": 15, "size": "medium"}
        if orientation:
            params["orientation"] = orientation
        try:
            r = requests.get("https://api.pexels.com/videos/search", params=params,
                             headers={"Authorization": key}, timeout=30)
            vids = r.json().get("videos", []) if r.status_code == 200 else []
        except (requests.RequestException, ValueError):
            vids = []
        vids = [v for v in vids if f"pexels-{v['id']}" not in used and 3 <= v.get("duration", 0) <= 120]
        random.shuffle(vids)
        for v in vids[:4]:
            f = _pick_file(v.get("video_files", []))
            if not f:
                continue
            path = _download(f["link"], CACHE / f"pexels-{v['id']}.mp4")
            if path:
                used.add(f"pexels-{v['id']}")
                return path
    return None


def pixabay_video(query: str, used: set) -> Path | None:
    key = env("PIXABAY_API_KEY")
    if not key:
        return None
    try:
        r = requests.get("https://pixabay.com/api/videos/",
                         params={"key": key, "q": query[:100], "per_page": 20, "safesearch": "true"},
                         timeout=30)
        hits = r.json().get("hits", []) if r.status_code == 200 else []
    except (requests.RequestException, ValueError):
        hits = []
    hits = [h for h in hits if f"pixabay-{h['id']}" not in used]
    random.shuffle(hits)
    for h in hits[:4]:
        vs = h.get("videos", {})
        f = _pick_file([dict(v, link=v.get("url")) for v in vs.values() if v.get("url")])
        if not f:
            continue
        path = _download(f["link"], CACHE / f"pixabay-{h['id']}.mp4")
        if path:
            used.add(f"pixabay-{h['id']}")
            return path
    return None


def ai_image(prompt: str, w: int, h: int) -> Path | None:
    """Free AI image from Pollinations (FLUX). A free key from enter.pollinations.ai
    (POLLINATIONS_API_KEY) gives better limits but is optional."""
    full = f"{prompt}, cinematic lighting, highly detailed, vertical composition, no text, no watermark"
    seed = random.randint(1, 999_999)
    q = urllib.parse.quote(full[:600])
    key = env("POLLINATIONS_API_KEY")
    name = hashlib.md5(f"{full}{seed}".encode()).hexdigest()[:16]
    dest = CACHE / f"ai-{name}.jpg"
    params = f"width={w}&height={h}&seed={seed}&nologo=true&model=flux"
    urls = []
    if key:
        urls.append(f"https://gen.pollinations.ai/image/{q}?{params}&key={key}")
    urls += [f"https://gen.pollinations.ai/image/{q}?{params}",
             f"https://image.pollinations.ai/prompt/{q}?{params}"]
    for url in urls:
        path = _download(url, dest, timeout=180)
        if path:
            return path
    return None


def fetch_visuals(scenes: list[dict], cfg: dict) -> list[dict]:
    """Adds scene['media'] = {"kind": "video"|"image"|"gradient", "path": Path|None}."""
    mode = cfg["video"].get("visual_mode", "stock")
    w, h = cfg["video"]["width"], cfg["video"]["height"]
    used: set = set()
    for i, s in enumerate(scenes):
        want_ai = mode == "ai" or (mode == "mixed" and i % 2 == 1)
        stock = lambda: pexels_video(s["visual"], used) or pixabay_video(s["visual"], used) \
            or pexels_video(" ".join(s["visual"].split()[:2]), used)
        ai = lambda: ai_image(s["image_prompt"], w, h)
        order = [("image", ai), ("video", stock)] if want_ai else [("video", stock), ("image", ai)]
        s["media"] = {"kind": "gradient", "path": None}
        for kind, fn in order:
            path = fn()
            if path:
                s["media"] = {"kind": kind, "path": path}
                break
        log(f"Scene {i + 1}: {s['media']['kind']:8s} ← '{s['visual']}'")
    return scenes
