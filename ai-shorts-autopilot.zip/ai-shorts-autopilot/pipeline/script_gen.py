"""Turns a topic into a 50–60 second narrated short: script, scenes, metadata."""
from __future__ import annotations

from .llm import generate_json
from .utils import log

SYSTEM = """You are a top short-form video scriptwriter for YouTube Shorts and Instagram Reels.
You write scripts that hook viewers in the first 2 seconds and keep them to the end.
Every fact must be accurate and widely verifiable — never invent statistics, quotes or studies.
If you are not sure about a number, describe it without the number.
Always reply with a single JSON object and nothing else."""

PROMPT = """Write a vertical short video about this topic:

TOPIC: {topic}

Channel niche: {niche}
Language of narration: {language}
Style: {style}

Rules:
- Total narration: {min_words}-{max_words} words (about {min_s}-{max_s} seconds spoken).
- Scene 1 is the HOOK: one bold, surprising sentence or question. No greetings, no "in this video".
- 6 to 9 scenes. Each scene is 1-2 short sentences of narration.
- Build curiosity scene by scene; the payoff comes near the end.
- Last scene: a quick satisfying conclusion plus a short call to action (e.g. "Follow for more{handle_hint}.").
- Write numbers the way they should be spoken.
- For each scene give "visual": 2-4 plain English keywords to search stock footage
  (concrete, filmable things — e.g. "ocean waves aerial", "old library books", NOT abstract ideas),
  and "image_prompt": a vivid prompt for an AI image generator, vertical 9:16, cinematic, no text.

Return JSON exactly in this shape:
{{
  "title": "catchy title under 70 characters, no hashtags",
  "scenes": [
    {{"text": "narration for this scene", "visual": "stock footage keywords", "image_prompt": "..."}}
  ],
  "description": "2-3 sentence YouTube description",
  "caption": "Instagram caption, 1-2 lines with 1-2 emojis",
  "hashtags": ["5 to 8 relevant hashtags without the # sign"],
  "tags": ["8-12 YouTube search tags"]
}}"""

TOPIC_SYSTEM = """You plan content for a faceless short-video channel. Reply with JSON only."""

TOPIC_PROMPT = """Suggest ONE fresh, specific, highly clickable topic for a 55-second short video.
Channel niche: {niche}
Language: {language}
It must be different from all of these recent videos:
{recent}

Prefer surprising facts, little-known stories and "why does X happen" questions.
Return: {{"topic": "..."}}"""


def invent_topic(cfg: dict, recent_titles: list[str]) -> str:
    ch = cfg["channel"]
    data = generate_json(
        TOPIC_SYSTEM,
        TOPIC_PROMPT.format(
            niche=ch["niche"], language=ch["language"],
            recent="\n".join(f"- {t}" for t in recent_titles[-40:]) or "- (none yet)",
        ),
        cfg,
    )
    topic = str(data.get("topic", "")).strip()
    if not topic:
        raise RuntimeError("LLM returned no topic")
    log(f"AI picked topic: {topic}")
    return topic


def _word_count(script: dict) -> int:
    return sum(len(s.get("text", "").split()) for s in script.get("scenes", []))


def write_script(topic: str, cfg: dict) -> dict:
    ch, vid = cfg["channel"], cfg["video"]
    # ~2.6 spoken words per second at the configured speed
    min_w = int(vid["min_seconds"] * 2.55)
    max_w = int(vid["max_seconds"] * 2.55)
    handle = ch.get("handle", "").strip()
    prompt = PROMPT.format(
        topic=topic, niche=ch["niche"], language=ch["language"], style=ch["style"],
        min_words=min_w, max_words=max_w, min_s=vid["min_seconds"], max_s=vid["max_seconds"],
        handle_hint=f" ({handle})" if handle else "",
    )

    best = None
    for attempt in range(3):
        script = generate_json(SYSTEM, prompt, cfg)
        scenes = [s for s in script.get("scenes", []) if str(s.get("text", "")).strip()]
        script["scenes"] = scenes
        if not scenes or not script.get("title"):
            log("Script missing scenes/title, retrying")
            continue
        n = _word_count(script)
        log(f"Script: '{script['title']}' — {len(scenes)} scenes, {n} words")
        best = script
        if min_w * 0.85 <= n <= max_w * 1.1:
            break
        prompt += f"\n\nIMPORTANT: your last draft had {n} words. It MUST be {min_w}-{max_w} words."
    if not best:
        raise RuntimeError("Could not generate a usable script")

    for s in best["scenes"]:
        s["text"] = " ".join(str(s["text"]).split())
        s["visual"] = str(s.get("visual") or topic)
        s["image_prompt"] = str(s.get("image_prompt") or s["visual"])
    best["hashtags"] = [h.strip().lstrip("#").replace(" ", "") for h in best.get("hashtags", []) if h.strip()]
    best["tags"] = [t.strip() for t in best.get("tags", []) if t.strip()]
    best["topic"] = topic
    return best
