# AI Shorts Autopilot

Fully automatic, ₹0 faceless-video channel. Twice a day it:

1. picks a topic (from your queue, or the AI invents one in your niche),
2. writes a 50–60 second script with Google Gemini (free),
3. records a natural AI voice-over with Microsoft neural voices (free, via edge-tts),
4. pulls matching vertical stock footage from Pexels/Pixabay (free) or AI images from Pollinations (free),
5. renders a 1080×1920 video with word-by-word captions, progress bar and optional music,
6. uploads it to **YouTube Shorts** and **Instagram Reels** through their official APIs,
7. updates a dashboard website where you manage topics and watch results.

Everything runs on **GitHub Actions** (the worker) and **GitHub Pages** (the website). No server, no card, no monthly bill.

```
 ┌────────────── GitHub (free, public repo) ──────────────┐
 │  Actions cron 2×/day ─► pipeline/ (Python + ffmpeg)    │
 │     Gemini ─► script   edge-tts ─► voice               │
 │     Pexels/Pixabay/Pollinations ─► visuals             │
 │     ffmpeg ─► video.mp4 ─► YouTube API                  │
 │                       └─► GitHub Pages ─► Instagram API │
 │  Pages website = dashboard (topics, history, preview)  │
 └────────────────────────────────────────────────────────┘
```

---

## Before you start — two things to know

**YouTube: uploads stay private until Google audits your API project.**
Google locks every video uploaded through a new, unaudited API project as *private*. The fix is free: submit the [YouTube API Services audit form](https://support.google.com/youtube/contact/yt_api_form) (step 5e). It usually takes a few weeks. The system works fully in the meantime — the videos are just private on YouTube. Instagram has no such restriction.

**Instagram needs a Professional account.** In the Instagram app: Settings → Account type and tools → Switch to professional account → Creator (free, 1 minute).

---

## Setup (about 45 minutes, once)

### 1. Put the code on GitHub
1. Create a free account at github.com.
2. Click **+ → New repository**. Name it e.g. `shorts-autopilot`. Choose **Public** (public repos get unlimited free Actions minutes and free Pages; your keys stay secret). Create it.
3. Upload this folder. The easiest way is **GitHub Desktop** (desktop.github.com): *File → Add local repository* → pick this folder → *Publish*. Or with git:
   ```bash
   cd ai-shorts-autopilot
   git init && git add . && git commit -m "first commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/shorts-autopilot.git
   git push -u origin main
   ```
   > Uploading through the browser often skips the hidden `.github` folder, which holds the schedule. Use GitHub Desktop or git.

### 2. Turn on the website and the robot's write access
- Repo **Settings → Pages → Build and deployment → Source: GitHub Actions**.
- Repo **Settings → Actions → General → Workflow permissions → Read and write permissions → Save**.

### 3. Get the free AI keys
Add each one at **Settings → Secrets and variables → Actions → New repository secret** (name on the left, value on the right).

| Secret name | Where to get it (free) | Needed? |
|---|---|---|
| `GEMINI_API_KEY` | aistudio.google.com/apikey → *Create API key* | **Yes** |
| `PEXELS_API_KEY` | pexels.com/api → *Get started* | **Yes** (for real footage) |
| `GROQ_API_KEY` | console.groq.com/keys | Backup if Gemini is down |
| `PIXABAY_API_KEY` | pixabay.com/api/docs (log in, key is on the page) | Backup footage |
| `POLLINATIONS_API_KEY` | enter.pollinations.ai | Optional; AI images work without it |

The voice (edge-tts) needs no key.

### 4. Test run (no uploading yet)
**Actions** tab → **Autopost** → **Run workflow** → untick *Upload to YouTube and Instagram* → **Run**.
After ~5 minutes open `https://YOUR_USERNAME.github.io/shorts-autopilot/` — your dashboard, with the first video playing. 🎉

### 5. Connect YouTube
a. Go to console.cloud.google.com → create a project (e.g. "shorts-autopilot").
b. **APIs & Services → Library** → search *YouTube Data API v3* → **Enable**.
c. **APIs & Services → OAuth consent screen** (Google Auth Platform) → External → fill app name + your email → add scope `.../auth/youtube.upload` → add yourself as a test user → then under **Audience** click **Publish app** (→ *In production*). Otherwise Google expires the login every 7 days. You don't need Google's verification for your own channel; you'll just see an "unverified app" warning once.
d. **Credentials → Create credentials → OAuth client ID → Desktop app** → **Download JSON**, save it as `tools/client_secret.json`.
   On your computer (needs Python 3):
   ```bash
   pip install google-auth-oauthlib
   python tools/get_youtube_token.py
   ```
   A browser opens → choose the Google account that owns the channel → *Advanced → Go to app → Continue*. It prints three values; add them as secrets `YT_CLIENT_ID`, `YT_CLIENT_SECRET`, `YT_REFRESH_TOKEN`. Don't commit `client_secret.json` (it's in `.gitignore`).
e. Submit the audit so videos can be public: support.google.com/youtube/contact/yt_api_form → *API Services audit*. Describe it honestly: "a personal tool that uploads my own AI-narrated educational Shorts to my own channel, twice a day". Link your dashboard as the website.

### 6. Connect Instagram
a. Make sure the Instagram account is **Professional** (Creator or Business).
b. developers.facebook.com → **My Apps → Create app** → use case **"Manage messaging & content on Instagram"** → type Business → create.
c. In the app: **Instagram → API setup with Instagram login**.
   - Under *App roles → Roles → Instagram testers*, add your Instagram username. In the Instagram app, accept it at *Settings → Apps and websites → Tester invites*.
   - Back in **API setup → Generate access tokens → Add account** → log in to Instagram → allow **content publish**.
   - Click **Generate token** and copy it.
d. Add secret `IG_ACCESS_TOKEN` = that token. (Optional `IG_USER_ID`; it's looked up automatically.)
   Your app can stay in **Development mode** — that's fine for posting to your own account, no App Review needed.
e. The token lasts 60 days. To renew it automatically, create a GitHub token: github.com/settings/personal-access-tokens → **Generate new token (fine-grained)** → *Only select repositories*: this repo → Permissions → **Secrets: Read and write** → generate, and save it as secret `GH_PAT`. The *Refresh Instagram token* workflow then renews it on the 1st and 15th of every month.

### 7. Unlock the dashboard controls
Create another fine-grained GitHub token for this repo only with **Contents: Read and write** and **Actions: Read and write**. Open your dashboard → **⚙ Settings** → paste it. It's stored only in that browser. Now you can add/remove/reorder topics, click suggestions to queue them, and press **Generate & post now**.

### 8. Done
Run **Autopost** once more with upload ticked to confirm both platforms work. From then on it posts by itself around **9 AM and 6 PM IST** every day.

---

## Everyday use
- **Choose what gets posted:** add topics in the dashboard (or click ideas). The top of the queue goes next. Empty queue = the AI invents topics in your niche.
- **Post right now:** type a topic → *Generate & post now* (~5–8 min).
- **Change niche, language, voice, captions, timing:** edit `config.yaml` on GitHub (pencil icon).
  - Hindi channel: `language: "Hindi"` and voices `hi-IN-MadhurNeural`, `hi-IN-SwaraNeural`.
  - All-AI visuals instead of stock footage: `visual_mode: "ai"`.
- **Change posting times:** edit the two `cron` lines in `.github/workflows/autopost.yml` (they are UTC; IST = UTC + 5:30) and the `SCHEDULE_UTC` line in `site/index.html`.
- **Background music:** add royalty-free `.mp3` files to `assets/music/` (e.g. from the YouTube Audio Library). Only use music you have the rights to.
- **If something fails:** GitHub emails you, and the dashboard shows it under *Recent runs* — click the run to see the log.

## Preview videos on your own computer
Needs Python 3.10+ and ffmpeg.
```bash
pip install -r requirements.txt
export GEMINI_API_KEY=... PEXELS_API_KEY=...      # Windows: set GEMINI_API_KEY=...
python -m pipeline.main make --topic "Why do cats purr"
# → out/video.mp4 (nothing is uploaded unless you add --youtube)
```

## Costs and limits (all ₹0)
| Piece | Free allowance | This project uses |
|---|---|---|
| GitHub Actions (public repo) | unlimited minutes | ~10 min/run |
| GitHub Pages | 1 GB site, 100 GB/month | a few videos |
| Gemini API free tier | ~1,500 requests/day (Flash) | ~3–6/day |
| Pexels / Pixabay | 200 / 100 requests per hour | ~10/run |
| edge-tts voices | no key, unofficial | 1/run (falls back to gTTS if it ever breaks) |
| YouTube Data API | 10,000 units/day | 1 upload/run |
| Instagram API | ~50 posts/24 h | 2/day |

Notes:
- On the Gemini free tier, Google may use prompts to improve its models. Fine here: they're just topic prompts.
- GitHub runs scheduled jobs late sometimes (5–30 min) and pauses schedules in repos with 60 days of no commits. This repo commits after every post, so it stays active.
- Videos are labelled as AI-generated on YouTube (`containsSyntheticMedia`). YouTube's monetisation rules penalise mass-produced, repetitive content, so curate topics and spot-check facts if you plan to monetise.

## Project layout
```
config.yaml                    all settings
data/topics.json               topic queue (edited by the dashboard)
data/history.json              everything posted
data/suggestions.json          topic ideas shown in the dashboard
pipeline/                      the video factory (Python)
  script_gen.py  llm.py        script writing (Gemini → Groq)
  tts.py                       voice + word timings
  media.py                     footage / AI images
  render.py                    ffmpeg editing + captions
  upload_youtube.py upload_instagram.py
site/index.html                the dashboard website
.github/workflows/autopost.yml twice-daily schedule
.github/workflows/refresh-instagram-token.yml
tools/get_youtube_token.py     one-time YouTube login helper
assets/fonts, assets/music     caption font (OFL licence), your music
```
